angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  var novonome = localStorage.getItem("Nome");

  document.getElementById("nome").innerHTML = novonome;
  

  // Perform the login action when the user submits the login form
  $scope.doCad = function() {
  
  var nome = document.getElementById("nome");
  var email = document.getElementById("email");
  var telefone = document.getElementById("telefone");
  var endereco = document.getElementById("endereco");

  localStorage.setItem("Endereco", endereco.value); 
  localStorage.setItem("Nome", nome.value);
  localStorage.setItem("Email", email.value);
  localStorage.setItem("Telefone", telefone.value);

  };

  $scope.exibir = function() {
  
    var nome = localStorage.getItem("Nome");
    var email = localStorage.getItem("Email");
    var telefone = localStorage.getItem("Telefone");

    document.getElementById("nome").value = nome;
    document.getElementById("email").value = email;
    document.getElementById("telefone").value = telefone;

  };

  $scope.enviaremail = function() {
  
    var nome = localStorage.getItem("Nome");
    var email = localStorage.getItem("Email");
    var reclamacao = document.getElementById("reclamacao");
    var assunto = localStorage.getItem("Assunto");
    var endereco = localStorage.getItem("Endereco");
    passaValor(nome, reclamacao, email, assunto, endereco);

  };


  var passaValor = function(nome, reclamacao, email, assunto)
{
    window.location = "caminhodoapp/enviar.php?nome="+nome+"&reclamacao="+reclamacao+"&email="+email+"&assunto="+assunto+"&endereco="+endereco;
}


  $scope.camera = function() {
  
      navigator.camera.getPicture(onSuccess, onFail, { quality: 1,
        destinationType: Camera.DestinationType.DATA_URL, saveToPhotoAlbum: false });

      function onSuccess(imageDATA) {
          var image = document.getElementById('imagem');
          image.style.display = "block";
          image.src = "data:image/jpeg;base64," + imageData;
          localStorage.setItem("Imagem", imageURI);
               
      }

      function onFail(message) {
          alert('Failed because: ' + message);
      }

  };

  $scope.album = function() {
  
      navigator.camera.getPicture(onSuccess, onFail, { quality: 50,
destinationType: Camera.DestinationType.DATA_URL,
sourceType : Camera.PictureSourceType.SAVEDPHOTOALBUM   });
  

      function onSuccess(imageData) {
      var image = document.getElementById('imagem');
      var semimagem = document.getElementById('semimagem');
      image.src = "data:image/jpeg;base64," + imageData;
      image.style.display = "block";
      semimagem.style.display = "none";
      }

      function onFail(message) {
      alert('Failed because: ' + message);
      }

  };



  $scope.Educacao = function() {
  
 localStorage.setItem("Assunto", "Educacao");

  };

  $scope.Infraestrutura = function() {

 localStorage.setItem("Assunto", "Infraestrutura");

  };

  $scope.Limpeza = function() {
  
  localStorage.setItem("Assunto", "Limpeza");

  };

  $scope.Saude = function() {
  
  localStorage.setItem("Assunto", "Saude");

  };

  $scope.Seguranca = function() {
  
  localStorage.setItem("Assunto", "Seguranca");

  };

  $scope.Transito = function() {
  
  localStorage.setItem("Assunto", "Transito");

  };

  $scope.TransportePublico = function() {
  
  localStorage.setItem("Assunto", "Transporte Publico");

  };


})

.controller('PlaylistsCtrl', function($scope) {
  $scope.playlists = [
    { title: 'Forró', id: 1 },
    { title: 'Chill', id: 2 },
    { title: 'Dubstep', id: 3 },
    { title: 'Indie', id: 4 },
    { title: 'Rap', id: 5 },
    { title: 'Cowbell', id: 6 }
  ];
})

.controller('PlaylistCtrl', function($scope, $stateParams) {
});


